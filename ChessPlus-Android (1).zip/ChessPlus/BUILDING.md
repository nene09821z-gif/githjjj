# Build và kiểm tra nhanh

## GitHub Actions

Workflow `.github/workflows/android.yml` tự cài JDK 17, Android SDK Platform 36 và Gradle 8.13; sau đó chạy test và assemble APK.

## Build cục bộ

Cài JDK 17, Android SDK Platform 36 và Gradle 8.13 rồi chạy:

```bash
gradle :app:testDebugUnitTest
gradle :app:assembleDebug
```

Có thể tạo Gradle Wrapper bằng `gradle wrapper --gradle-version 8.13` rồi dùng `./gradlew` trên Linux/macOS hoặc `gradlew.bat` trên Windows.

## Đầu ra

```text
app/build/outputs/apk/debug/app-debug.apk
```
