# Keep Room generated accessors and Firebase model fields if minification is enabled later.
-keepattributes *Annotation*
-keep class com.example.chessplus.data.** { *; }
