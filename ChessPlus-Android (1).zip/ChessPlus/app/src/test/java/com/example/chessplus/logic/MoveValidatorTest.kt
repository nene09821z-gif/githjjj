package com.example.chessplus.logic

import com.example.chessplus.model.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MoveValidatorTest {
    private fun play(state: GameState, from: String, to: String, promotion: PieceType? = null): GameState {
        val source = Position.fromAlgebraic(from)!!
        val target = Position.fromAlgebraic(to)!!
        val move = MoveValidator.legalMoves(state).firstOrNull {
            it.from == source && it.to == target && it.promotionType == promotion
        }
        assertNotNull("Nước $from-$to phải hợp lệ", move)
        return MoveValidator.applyMove(state, move!!)!!
    }

    @Test fun initialPositionHasTwentyLegalMoves() {
        assertEquals(20, MoveValidator.legalMoves(GameState.newGame()).size)
    }

    @Test fun pawnCanAdvanceOneOrTwoSquaresOnFirstMove() {
        val state = GameState.newGame()
        val moves = MoveValidator.legalMovesFrom(state, Position.fromAlgebraic("e2")!!)
        assertTrue(moves.any { it.to.toAlgebraic() == "e3" })
        assertTrue(moves.any { it.to.toAlgebraic() == "e4" })
        assertFalse(moves.any { it.to.toAlgebraic() == "e5" })
    }

    @Test fun knightMovesInLShape() {
        val moves = MoveValidator.legalMovesFrom(GameState.newGame(), Position.fromAlgebraic("g1")!!)
        assertEquals(setOf("f3", "h3"), moves.map { it.to.toAlgebraic() }.toSet())
    }

    @Test fun piecesCannotJumpOverBlockingPieces() {
        val moves = MoveValidator.legalMovesFrom(GameState.newGame(), Position.fromAlgebraic("f1")!!)
        assertTrue(moves.isEmpty())
    }

    @Test fun pinnedRookCannotExposeItsKing() {
        val state = ChessFen.fromFen("4r1k1/8/8/8/8/8/4R3/4K3 w - - 0 1")!!
        val moves = MoveValidator.legalMovesFrom(state, Position.fromAlgebraic("e2")!!)
        assertFalse(moves.any { it.to == Position.fromAlgebraic("d2") })
        assertTrue(moves.any { it.to == Position.fromAlgebraic("e3") })
    }

    @Test fun bothCastlingSidesAreGeneratedWhenPathIsClear() {
        val state = ChessFen.fromFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1")!!
        val moves = MoveValidator.legalMovesFrom(state, Position.fromAlgebraic("e1")!!)
        assertTrue(moves.any { it.isCastling && it.to.toAlgebraic() == "g1" })
        assertTrue(moves.any { it.isCastling && it.to.toAlgebraic() == "c1" })
    }

    @Test fun cannotCastleThroughAnAttackedSquare() {
        val state = ChessFen.fromFen("5r1k/8/8/8/8/8/8/4K2R w K - 0 1")!!
        val moves = MoveValidator.legalMovesFrom(state, Position.fromAlgebraic("e1")!!)
        assertFalse(moves.any { it.isCastling })
    }

    @Test fun enPassantIsAvailableImmediatelyAfterDoublePawnMove() {
        var state = GameState.newGame()
        state = play(state, "e2", "e4")
        state = play(state, "a7", "a6")
        state = play(state, "e4", "e5")
        state = play(state, "d7", "d5")
        val move = MoveValidator.legalMovesFrom(state, Position.fromAlgebraic("e5")!!)
            .firstOrNull { it.to.toAlgebraic() == "d6" }
        assertNotNull(move)
        assertTrue(move!!.isEnPassant)
    }

    @Test fun pawnPromotionOffersFourPieces() {
        val state = ChessFen.fromFen("7k/P7/8/8/8/8/8/7K w - - 0 1")!!
        val moves = MoveValidator.legalMovesFrom(state, Position.fromAlgebraic("a7")!!)
            .filter { it.to.toAlgebraic() == "a8" }
        assertEquals(setOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT), moves.mapNotNull { it.promotionType }.toSet())
    }

    @Test fun undoRestoresThePreviousPositionAndTurn() {
        val after = play(GameState.newGame(), "e2", "e4")
        val before = MoveValidator.undo(after)
        assertNotNull(before)
        assertEquals(PieceColor.WHITE, before!!.currentTurn)
        assertEquals(PieceType.PAWN, before.board[Position.fromAlgebraic("e2")!!]?.type)
    }

    @Test fun threefoldRepetitionCanBeClaimed() {
        var state = GameState.newGame()
        repeat(2) {
            state = play(state, "g1", "f3")
            state = play(state, "g8", "f6")
            state = play(state, "f3", "g1")
            state = play(state, "f6", "g8")
        }
        assertEquals(GameStatus.ACTIVE, state.status)
        assertEquals(GameStatus.DRAW_THREEFOLD, MoveValidator.claimableDrawStatus(state))
    }

    @Test fun fivefoldRepetitionIsAutomaticDraw() {
        var state = GameState.newGame()
        repeat(4) {
            state = play(state, "g1", "f3")
            state = play(state, "g8", "f6")
            state = play(state, "f3", "g1")
            state = play(state, "f6", "g8")
        }
        assertEquals(GameStatus.DRAW_FIVEFOLD_REPETITION, state.status)
    }

    @Test fun fiftyMoveDrawCanBeClaimed() {
        val state = ChessFen.fromFen("6k1/8/8/8/8/8/8/R5K1 w - - 100 51")!!
        assertEquals(GameStatus.DRAW_FIFTY_MOVE, MoveValidator.claimableDrawStatus(state))
    }

    @Test fun seventyFiveMoveDrawIsAutomatic() {
        val state = ChessFen.fromFen("6k1/8/8/8/8/8/8/R5K1 w - - 150 76")!!
        assertEquals(GameStatus.DRAW_SEVENTY_FIVE_MOVE, state.status)
    }
    @Test fun detectsCheckmateAndStalemate() {
        val matePosition = ChessFen.fromFen("7k/6pp/5Q2/8/8/8/6PP/6K1 w - - 0 1")!!
        val mateMove = MoveValidator.legalMoves(matePosition).first {
            it.from == Position.fromAlgebraic("f6") && it.to == Position.fromAlgebraic("f8")
        }
        val afterMate = MoveValidator.applyMove(matePosition, mateMove)!!
        assertEquals(GameStatus.CHECKMATE, afterMate.status)

        val stalematePosition = ChessFen.fromFen("7k/5Q2/6K1/8/8/8/8/8 b - - 0 1")!!
        assertEquals(GameStatus.STALEMATE, stalematePosition.status)
    }

    @Test fun sanNotationMarksCastlingAndCheckmate() {
        val castlePosition = ChessFen.fromFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1")!!
        val castle = MoveValidator.legalMovesFrom(castlePosition, Position.fromAlgebraic("e1")!!)
            .first { it.to == Position.fromAlgebraic("g1") }
        assertEquals("O-O", MoveValidator.applyMove(castlePosition, castle)!!.moveHistory.last().notation)

        val matePosition = ChessFen.fromFen("7k/6pp/5Q2/8/8/8/6PP/6K1 w - - 0 1")!!
        val mate = MoveValidator.legalMovesFrom(matePosition, Position.fromAlgebraic("f6")!!)
            .first { it.to == Position.fromAlgebraic("f8") }
        assertEquals("Qf8#", MoveValidator.applyMove(matePosition, mate)!!.moveHistory.last().notation)
    }

    @Test fun gameOverPositionHasNoLegalMoves() {
        val stalemate = ChessFen.fromFen("7k/5Q2/6K1/8/8/8/8/8 b - - 0 1")!!
        assertTrue(stalemate.isGameOver)
        assertTrue(MoveValidator.legalMoves(stalemate).isEmpty())
    }

}
