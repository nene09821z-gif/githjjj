package com.example.chessplus.data

import com.example.chessplus.logic.ChessFen
import com.example.chessplus.model.GameState
import kotlinx.coroutines.flow.Flow

class GameRepository(private val dao: SavedGameDao) {
    val savedGames: Flow<List<SavedGameEntity>> = dao.observeAll()

    suspend fun saveFinishedGame(state: GameState): Long = dao.insert(
        SavedGameEntity(
            finishedAt = System.currentTimeMillis(),
            result = state.status.name,
            movesSan = state.moveHistory.joinToString(" ") { it.notation },
            movesUci = state.moveHistory.joinToString(" ") { it.toUci() },
            finalFen = ChessFen.toFen(state)
        )
    )

    suspend fun delete(id: Long) = dao.delete(id)
}
