package com.example.chessplus.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.chessplus.model.GameState
import com.example.chessplus.model.GameStatus
import com.example.chessplus.model.PieceColor

@Composable
fun GameStatusBar(
    game: GameState,
    isAiThinking: Boolean,
    puzzleFeedback: String?,
    onlineCode: String?,
    modifier: Modifier = Modifier
) {
    val message = when (game.status) {
        GameStatus.ACTIVE -> "Lượt ${if (game.currentTurn == PieceColor.WHITE) "Trắng" else "Đen"}"
        GameStatus.CHECK -> "Chiếu! ${if (game.currentTurn == PieceColor.WHITE) "Trắng" else "Đen"} phải bảo vệ vua"
        GameStatus.CHECKMATE -> "Chiếu bí — ${if (game.currentTurn == PieceColor.WHITE) "Đen" else "Trắng"} thắng"
        GameStatus.STALEMATE -> "Hòa — hết nước đi hợp lệ (Stalemate)"
        GameStatus.DRAW_FIFTY_MOVE -> "Hòa theo luật 50 nước"
        GameStatus.DRAW_THREEFOLD -> "Hòa theo yêu cầu: lặp lại vị trí 3 lần"
        GameStatus.DRAW_SEVENTY_FIVE_MOVE -> "Hòa tự động theo luật 75 nước"
        GameStatus.DRAW_FIVEFOLD_REPETITION -> "Hòa tự động do lặp vị trí 5 lần"
        GameStatus.DRAW_INSUFFICIENT_MATERIAL -> "Hòa do không đủ quân chiếu bí"
    }
    val critical = game.status == GameStatus.CHECK || game.status == GameStatus.CHECKMATE
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(
                if (critical) Color(0xFFFFE2DD) else MaterialTheme.colorScheme.surfaceVariant,
                RoundedCornerShape(14.dp)
            )
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text(message, fontWeight = FontWeight.Bold, color = if (critical) Color(0xFF9E231A) else MaterialTheme.colorScheme.onSurface)
            Text("Nước ${game.moveHistory.size}", style = MaterialTheme.typography.labelMedium)
        }
        if (isAiThinking) Text("AI đang tính nước đi…", style = MaterialTheme.typography.bodySmall)
        if (onlineCode != null) Text("Phòng online: $onlineCode", style = MaterialTheme.typography.bodySmall)
        if (!puzzleFeedback.isNullOrBlank()) Text(puzzleFeedback, style = MaterialTheme.typography.bodySmall)
    }
}
