package com.example.chessplus.logic

import com.example.chessplus.model.*

/** Đọc/ghi FEN để khôi phục ván, đồng bộ online và nạp thế cờ puzzle. */
object ChessFen {
    fun toFen(state: GameState): String {
        val placement = (0..7).joinToString("/") { row ->
            buildString {
                var empty = 0
                for (col in 0..7) {
                    val piece = state.board[Position(row, col)]
                    if (piece == null) empty++ else {
                        if (empty > 0) { append(empty); empty = 0 }
                        val char = when (piece.type) {
                            PieceType.KING -> 'k'
                            PieceType.QUEEN -> 'q'
                            PieceType.ROOK -> 'r'
                            PieceType.BISHOP -> 'b'
                            PieceType.KNIGHT -> 'n'
                            PieceType.PAWN -> 'p'
                        }
                        append(if (piece.color == PieceColor.WHITE) char.uppercaseChar() else char)
                    }
                }
                if (empty > 0) append(empty)
            }
        }
        val castling = buildString {
            if (state.castlingRights.whiteKingSide) append('K')
            if (state.castlingRights.whiteQueenSide) append('Q')
            if (state.castlingRights.blackKingSide) append('k')
            if (state.castlingRights.blackQueenSide) append('q')
            if (isEmpty()) append('-')
        }
        return "$placement ${if (state.currentTurn == PieceColor.WHITE) "w" else "b"} $castling ${state.enPassantTarget?.toAlgebraic() ?: "-"} ${state.halfMoveClock} ${state.fullMoveNumber}"
    }

    fun fromFen(fen: String): GameState? = runCatching {
        val parts = fen.trim().split(Regex("\\s+"))
        require(parts.size >= 4)
        val ranks = parts[0].split('/')
        require(ranks.size == 8)
        var board = Board.empty()
        ranks.forEachIndexed { row, rankText ->
            var col = 0
            rankText.forEach { char ->
                if (char.isDigit()) {
                    col += char.digitToInt()
                } else {
                    val color = if (char.isUpperCase()) PieceColor.WHITE else PieceColor.BLACK
                    val type = when (char.lowercaseChar()) {
                        'k' -> PieceType.KING
                        'q' -> PieceType.QUEEN
                        'r' -> PieceType.ROOK
                        'b' -> PieceType.BISHOP
                        'n' -> PieceType.KNIGHT
                        'p' -> PieceType.PAWN
                        else -> error("Quân cờ FEN không hợp lệ")
                    }
                    require(col in 0..7)
                    board = board.put(Piece(type, color, Position(row, col)), Position(row, col))
                    col++
                }
            }
            require(col == 8)
        }
        val turn = if (parts[1] == "w") PieceColor.WHITE else PieceColor.BLACK
        val rightsText = parts[2]
        val rights = CastlingRights(
            whiteKingSide = 'K' in rightsText,
            whiteQueenSide = 'Q' in rightsText,
            blackKingSide = 'k' in rightsText,
            blackQueenSide = 'q' in rightsText
        )
        val state = GameState(
            board = board,
            currentTurn = turn,
            castlingRights = rights,
            enPassantTarget = if (parts[3] == "-") null else Position.fromAlgebraic(parts[3]),
            halfMoveClock = parts.getOrNull(4)?.toIntOrNull() ?: 0,
            fullMoveNumber = parts.getOrNull(5)?.toIntOrNull() ?: 1
        )
        val counted = state.copy(repetitionCounts = mapOf(GameState.positionKey(state) to 1))
        counted.copy(status = MoveValidator.determineStatus(counted))
    }.getOrNull()

    fun replayUci(moves: String): GameState {
        var state = GameState.newGame()
        moves.trim().split(Regex("\\s+")).filter { it.length >= 4 }.forEach { uci ->
            val from = Position.fromAlgebraic(uci.substring(0, 2)) ?: return@forEach
            val to = Position.fromAlgebraic(uci.substring(2, 4)) ?: return@forEach
            val promotion = uci.getOrNull(4)?.let { char ->
                when (char.lowercaseChar()) {
                    'q' -> PieceType.QUEEN
                    'r' -> PieceType.ROOK
                    'b' -> PieceType.BISHOP
                    'n' -> PieceType.KNIGHT
                    else -> null
                }
            }
            val move = MoveValidator.legalMoves(state).firstOrNull {
                it.from == from && it.to == to && it.promotionType == promotion
            } ?: return@forEach
            state = MoveValidator.applyMove(state, move) ?: state
        }
        return state
    }
}
