package com.example.chessplus.ui

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.chessplus.model.GameStatus
import com.example.chessplus.model.PieceColor
import com.example.chessplus.model.PieceType
import com.example.chessplus.logic.MoveValidator
import com.example.chessplus.model.Position
import com.example.chessplus.puzzle.PuzzleRepository
import com.example.chessplus.viewmodel.BoardTheme
import com.example.chessplus.viewmodel.ChessUiState
import com.example.chessplus.viewmodel.ChessViewModel
import com.example.chessplus.viewmodel.PlayerMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BoardScreen(viewModel: ChessViewModel) {
    val ui by viewModel.uiState.collectAsStateWithLifecycle()
    var showHistory by remember { mutableStateOf(false) }
    var showOnline by remember { mutableStateOf(false) }
    var showPuzzles by remember { mutableStateOf(false) }
    var showThemes by remember { mutableStateOf(false) }
    var roomCodeInput by remember { mutableStateOf("") }
    val toneGenerator = remember { runCatching { ToneGenerator(AudioManager.STREAM_MUSIC, 75) }.getOrNull() }
    var previousMoveCount by remember { mutableIntStateOf(ui.game.moveHistory.size) }
    DisposableEffect(toneGenerator) { onDispose { toneGenerator?.release() } }
    LaunchedEffect(ui.game.moveHistory.size) {
        val currentCount = ui.game.moveHistory.size
        if (currentCount > previousMoveCount) {
            val last = ui.game.moveHistory.lastOrNull()
            val tone = if (last?.capturedPiece != null || last?.isEnPassant == true) {
                ToneGenerator.TONE_PROP_ACK
            } else {
                ToneGenerator.TONE_PROP_BEEP
            }
            toneGenerator?.startTone(tone, 100)
        }
        previousMoveCount = currentCount
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("ChessPlus", fontWeight = FontWeight.Bold)
                        Text("Cờ vua • Compose + Kotlin", style = MaterialTheme.typography.labelSmall)
                    }
                },
                actions = {
                    TextButton(onClick = { showHistory = true }) { Text("Lịch sử") }
                }
            )
        }
    ) { insets ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(insets)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            GameStatusBar(
                game = ui.game,
                isAiThinking = ui.isAiThinking,
                puzzleFeedback = ui.puzzleFeedback,
                onlineCode = ui.onlineRoomCode
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FilterChip(
                    selected = ui.playerMode == PlayerMode.TWO_PLAYERS,
                    onClick = { viewModel.setMode(PlayerMode.TWO_PLAYERS) },
                    enabled = !ui.onlineActive,
                    label = { Text("2 người") },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = ui.playerMode == PlayerMode.VS_AI,
                    onClick = { viewModel.setMode(PlayerMode.VS_AI) },
                    enabled = !ui.onlineActive,
                    label = { Text("Đấu AI") },
                    modifier = Modifier.weight(1f)
                )
            }

            ChessBoard(ui = ui, onSquareClick = viewModel::onSquareTap)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { viewModel.newGame() }, modifier = Modifier.weight(1f)) { Text("Ván mới") }
                OutlinedButton(
                    onClick = viewModel::undo,
                    enabled = ui.game.moveHistory.isNotEmpty() && !ui.isAiThinking && !ui.onlineActive,
                    modifier = Modifier.weight(1f)
                ) { Text("Undo") }
                OutlinedButton(onClick = viewModel::flipBoard, modifier = Modifier.weight(1f)) { Text("Lật bàn") }
            }

            if (MoveValidator.claimableDrawStatus(ui.game) != null) {
                OutlinedButton(onClick = viewModel::claimDraw, modifier = Modifier.fillMaxWidth()) {
                    Text("Yêu cầu hòa (50 nước / lặp 3 lần)")
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(onClick = { showThemes = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Theme: ${ui.theme.name.lowercase().replaceFirstChar { it.uppercase() }}")
                    }
                    DropdownMenu(expanded = showThemes, onDismissRequest = { showThemes = false }) {
                        BoardTheme.entries.forEach { theme ->
                            DropdownMenuItem(
                                text = { Text(theme.name.lowercase().replaceFirstChar { it.uppercase() }) },
                                onClick = { viewModel.setTheme(theme); showThemes = false }
                            )
                        }
                    }
                }
                OutlinedButton(onClick = { showPuzzles = true }, modifier = Modifier.weight(1f)) { Text("Puzzle") }
                OutlinedButton(onClick = { showOnline = true }, modifier = Modifier.weight(1f)) { Text("Online") }
            }

            MoveHistory(ui)

            if (ui.reviewingGameId != null) {
                Text(
                    "Đang xem lại ván đã lưu • nhấn Ván mới để thoát chế độ xem",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }

    ui.pendingPromotion?.let { options ->
        AlertDialog(
            onDismissRequest = { },
            title = { Text("Chọn quân phong cấp") },
            text = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    options.forEach { move ->
                        Button(onClick = { move.promotionType?.let(viewModel::choosePromotion) }) {
                            Text(
                                when (move.promotionType) {
                                    PieceType.QUEEN -> "♕ Hậu"
                                    PieceType.ROOK -> "♖ Xe"
                                    PieceType.BISHOP -> "♗ Tượng"
                                    PieceType.KNIGHT -> "♘ Mã"
                                    else -> "?"
                                }
                            )
                        }
                    }
                }
            },
            confirmButton = { }
        )
    }

    if (showHistory) {
        AlertDialog(
            onDismissRequest = { showHistory = false },
            title = { Text("Các ván đã lưu") },
            text = {
                if (ui.savedGames.isEmpty()) {
                    Text("Chưa có ván kết thúc nào được lưu.")
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ui.savedGames, key = { it.id }) { saved ->
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable {
                                    viewModel.reviewSavedGame(saved)
                                    showHistory = false
                                },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(Modifier.padding(10.dp)) {
                                    Text(saved.result.replace('_', ' '), fontWeight = FontWeight.Bold)
                                    Text(java.text.DateFormat.getDateTimeInstance().format(java.util.Date(saved.finishedAt)))
                                    Text(saved.movesSan.ifBlank { "Ván chưa có nước đi" }, style = MaterialTheme.typography.bodySmall)
                                    Text("Chạm để xem lại", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showHistory = false }) { Text("Đóng") } }
        )
    }

    if (showOnline) {
        AlertDialog(
            onDismissRequest = { showOnline = false },
            title = { Text("Chơi online") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Tạo phòng để nhận mã 6 chữ số, hoặc nhập mã bạn bè gửi.")
                    OutlinedTextField(
                        value = roomCodeInput,
                        onValueChange = { roomCodeInput = it.filter(Char::isDigit).take(6) },
                        label = { Text("Mã phòng") },
                        singleLine = true
                    )
                    if (ui.onlineError != null) Text(ui.onlineError!!, color = MaterialTheme.colorScheme.error)
                    if (ui.onlineRoomCode != null) Text("Mã phòng hiện tại: ${ui.onlineRoomCode}", fontWeight = FontWeight.Bold)
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = { viewModel.createOnlineRoom(); showOnline = false }) { Text("Tạo phòng") }
                    TextButton(onClick = { viewModel.joinOnlineRoom(roomCodeInput); showOnline = false }, enabled = roomCodeInput.length == 6) { Text("Tham gia") }
                }
            },
            dismissButton = { TextButton(onClick = { showOnline = false }) { Text("Đóng") } }
        )
    }

    if (showPuzzles) {
        AlertDialog(
            onDismissRequest = { showPuzzles = false },
            title = { Text("Chọn Puzzle") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PuzzleRepository.puzzles.forEachIndexed { index, puzzle ->
                        OutlinedButton(
                            onClick = { viewModel.loadPuzzle(index); showPuzzles = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.fillMaxWidth()) {
                                Text(puzzle.title, fontWeight = FontWeight.Bold)
                                Text(puzzle.description, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPuzzles = false }) { Text("Đóng") } }
        )
    }
}

@Composable
private fun ChessBoard(ui: ChessUiState, onSquareClick: (Position) -> Unit) {
    val game = ui.game
    val lastMove = game.moveHistory.lastOrNull()
    val checkedKing = if (game.status == GameStatus.CHECK || game.status == GameStatus.CHECKMATE) {
        game.board.findKing(game.currentTurn)
    } else null
    val (light, dark) = boardColors(ui.theme)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(8.dp))
            .border(2.dp, Color(0xFF5B4635), RoundedCornerShape(8.dp))
    ) {
        for (displayRow in 0..7) {
            Row(modifier = Modifier.weight(1f)) {
                for (displayCol in 0..7) {
                    val row = if (ui.flipped) 7 - displayRow else displayRow
                    val col = if (ui.flipped) 7 - displayCol else displayCol
                    val position = Position(row, col)
                    val piece = game.board[position]
                    val isSelected = ui.selected == position
                    val isLast = lastMove?.from == position || lastMove?.to == position
                    val isCheck = checkedKing == position
                    val legalMove = ui.legalTargets.firstOrNull { it.to == position }
                    val baseColor = if ((row + col) % 2 == 0) light else dark
                    val targetColor = when {
                        isCheck -> Color(0xFFD94D45)
                        isSelected -> Color(0xFFE9C949)
                        isLast -> Color(0x66F5D76E)
                        else -> baseColor
                    }
                    val animatedColor by animateColorAsState(targetColor, label = "square-color")
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .background(animatedColor)
                            .border(0.25.dp, Color.Black.copy(alpha = 0.08f))
                            .clickable { onSquareClick(position) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (legalMove != null) {
                            Canvas(Modifier.fillMaxSize()) {
                                if (piece == null) {
                                    drawCircle(Color(0x770D1B16), radius = size.minDimension * 0.13f)
                                } else {
                                    drawCircle(
                                        Color(0xAA9C2B24),
                                        radius = size.minDimension * 0.39f,
                                        style = Stroke(width = size.minDimension * 0.07f)
                                    )
                                }
                            }
                        }
                        if (piece != null) PieceComposable(piece, selected = isSelected, moving = lastMove?.to == position)
                        if (displayCol == 0) {
                            Text(
                                text = (8 - row).toString(),
                                modifier = Modifier.align(Alignment.TopStart).padding(2.dp),
                                fontSize = 8.sp,
                                color = if ((row + col) % 2 == 0) dark else light,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (displayRow == 7) {
                            Text(
                                text = ('a'.code + col).toChar().toString(),
                                modifier = Modifier.align(Alignment.BottomEnd).padding(2.dp),
                                fontSize = 8.sp,
                                color = if ((row + col) % 2 == 0) dark else light,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MoveHistory(ui: ChessUiState) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Nước đi", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
        if (ui.game.moveHistory.isEmpty()) {
            Text("Trắng đi trước — chạm quân rồi chạm ô đích.", style = MaterialTheme.typography.bodySmall)
        } else {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                ui.game.moveHistory.forEachIndexed { index, move ->
                    if (index % 2 == 0) Text("${index / 2 + 1}.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(move.notation.ifBlank { move.toUci() }, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

private fun boardColors(theme: BoardTheme): Pair<Color, Color> = when (theme) {
    BoardTheme.CLASSIC -> Color(0xFFF0D9B5) to Color(0xFFB58863)
    BoardTheme.WOOD -> Color(0xFFE5C59B) to Color(0xFF8B5A37)
    BoardTheme.MARBLE -> Color(0xFFE9E8E3) to Color(0xFF858B91)
    BoardTheme.DARK -> Color(0xFF64748B) to Color(0xFF1E293B)
}
