package com.example.chessplus.online

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.Locale
import kotlin.random.Random

/**
 * Đồng bộ online tối giản qua Realtime Database.
 * Yêu cầu google-services.json, bật Anonymous Authentication và Realtime Database.
 */
class FirebaseOnlineRepository {
    data class RoomUpdate(val fen: String, val uciMoves: String, val whiteUid: String, val blackUid: String, val status: String, val myUid: String)

    private fun auth() = FirebaseAuth.getInstance()
    private fun root() = FirebaseDatabase.getInstance().reference.child("chessplus_rooms")

    fun createRoom(callback: (Result<String>) -> Unit) {
        runCatching { auth() }.onFailure { callback(Result.failure(it)); return }
        auth().signInAnonymously().addOnSuccessListener { authResult ->
            val uid = authResult.user?.uid
            if (uid == null) { callback(Result.failure(IllegalStateException("Không lấy được user id"))); return@addOnSuccessListener }
            val code = (100000..999999).random().toString()
            val payload = mapOf(
                "whiteUid" to uid,
                "blackUid" to "",
                "fen" to "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
                "uciMoves" to "",
                "status" to "ACTIVE",
                "updatedAt" to System.currentTimeMillis()
            )
            root().child(code).setValue(payload)
                .addOnSuccessListener { callback(Result.success(code)) }
                .addOnFailureListener { callback(Result.failure(it)) }
        }.addOnFailureListener { callback(Result.failure(it)) }
    }

    fun joinRoom(codeInput: String, callback: (Result<String>) -> Unit) {
        val code = codeInput.trim()
        if (!code.matches(Regex("\\d{6}"))) {
            callback(Result.failure(IllegalArgumentException("Mã phòng phải gồm 6 chữ số")))
            return
        }
        runCatching { auth() }.onFailure { callback(Result.failure(it)); return }
        auth().signInAnonymously().addOnSuccessListener { authResult ->
            val uid = authResult.user?.uid
            if (uid == null) { callback(Result.failure(IllegalStateException("Không lấy được user id"))); return@addOnSuccessListener }
            val roomRef = root().child(code)
            roomRef.get().addOnSuccessListener { snapshot ->
                if (!snapshot.exists()) {
                    callback(Result.failure(IllegalStateException("Không tìm thấy phòng $code")))
                    return@addOnSuccessListener
                }
                val whiteUid = snapshot.child("whiteUid").getValue(String::class.java).orEmpty()
                val blackUid = snapshot.child("blackUid").getValue(String::class.java).orEmpty()
                if (uid != whiteUid && blackUid.isNotEmpty() && uid != blackUid) {
                    callback(Result.failure(IllegalStateException("Phòng đã đủ người")))
                } else if (uid == whiteUid || uid == blackUid) {
                    callback(Result.success(code))
                } else {
                    roomRef.child("blackUid").setValue(uid)
                        .addOnSuccessListener { callback(Result.success(code)) }
                        .addOnFailureListener { callback(Result.failure(it)) }
                }
            }.addOnFailureListener { callback(Result.failure(it)) }
        }.addOnFailureListener { callback(Result.failure(it)) }
    }

    fun publish(code: String, fen: String, moves: String, status: String) {
        runCatching {
            root().child(code).updateChildren(
                mapOf("fen" to fen, "uciMoves" to moves, "status" to status, "updatedAt" to System.currentTimeMillis())
            )
        }
    }

    fun observe(code: String, onUpdate: (RoomUpdate) -> Unit, onError: (String) -> Unit): () -> Unit {
        val reference = root().child(code)
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val fen = snapshot.child("fen").getValue(String::class.java).orEmpty()
                val moves = snapshot.child("uciMoves").getValue(String::class.java).orEmpty()
                val white = snapshot.child("whiteUid").getValue(String::class.java).orEmpty()
                val black = snapshot.child("blackUid").getValue(String::class.java).orEmpty()
                val status = snapshot.child("status").getValue(String::class.java).orEmpty()
                if (fen.isNotBlank()) onUpdate(RoomUpdate(fen, moves, white, black, status, auth().currentUser?.uid.orEmpty()))
            }
            override fun onCancelled(error: DatabaseError) = onError(error.message)
        }
        reference.addValueEventListener(listener)
        return { reference.removeEventListener(listener) }
    }
}
