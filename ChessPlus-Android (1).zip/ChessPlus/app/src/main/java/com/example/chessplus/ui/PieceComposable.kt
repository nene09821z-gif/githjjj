package com.example.chessplus.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.chessplus.model.Piece
import com.example.chessplus.model.PieceColor

@Composable
fun PieceComposable(
    piece: Piece,
    selected: Boolean = false,
    moving: Boolean = false,
    modifier: Modifier = Modifier
) {
    // Quân mới đến ô đích xuất hiện bằng hiệu ứng nảy nhẹ.
    val moveScale = remember { Animatable(if (moving) 0.78f else 1f) }
    LaunchedEffect(piece.position, moving) {
        if (moving) moveScale.animateTo(1f, spring(dampingRatio = 0.62f, stiffness = 520f))
        else moveScale.snapTo(1f)
    }
    val selectionScale by animateFloatAsState(
        targetValue = if (selected) 1.12f else 1f,
        label = "piece-selection-scale"
    )
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            text = piece.unicode(),
            color = if (piece.color == PieceColor.WHITE) Color(0xFFFFFEF8) else Color(0xFF202124),
            fontSize = 34.sp,
            fontWeight = FontWeight.Normal,
            style = TextStyle(
                shadow = Shadow(
                    color = if (piece.color == PieceColor.WHITE) Color(0xFF3C3026) else Color(0x55FFFFFF),
                    blurRadius = 3f
                )
            ),
            modifier = Modifier.graphicsLayer {
                scaleX = moveScale.value * selectionScale
                scaleY = moveScale.value * selectionScale
            }
        )
    }
}
