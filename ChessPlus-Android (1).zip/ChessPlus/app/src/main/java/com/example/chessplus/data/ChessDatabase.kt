package com.example.chessplus.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [SavedGameEntity::class], version = 1, exportSchema = false)
abstract class ChessDatabase : RoomDatabase() {
    abstract fun savedGameDao(): SavedGameDao

    companion object {
        @Volatile private var INSTANCE: ChessDatabase? = null

        fun getInstance(context: Context): ChessDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                ChessDatabase::class.java,
                "chessplus.db"
            ).build().also { INSTANCE = it }
        }
    }
}
