package com.example.chessplus.viewmodel

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.chessplus.ai.ChessAi
import com.example.chessplus.data.GameRepository
import com.example.chessplus.data.SavedGameEntity
import com.example.chessplus.logic.ChessFen
import com.example.chessplus.logic.MoveValidator
import com.example.chessplus.model.*
import com.example.chessplus.online.FirebaseOnlineRepository
import com.example.chessplus.puzzle.PuzzleRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChessViewModel(
    private val savedStateHandle: SavedStateHandle,
    private val repository: GameRepository
) : ViewModel() {
    private val onlineRepository = FirebaseOnlineRepository()
    private var removeOnlineListener: (() -> Unit)? = null
    private val _uiState = MutableStateFlow(
        ChessUiState(game = savedStateHandle.get<GameState>(KEY_GAME) ?: GameState.newGame())
    )
    val uiState: StateFlow<ChessUiState> = _uiState.asStateFlow()
    private var lastSavedGameToken: String? = null

    init {
        viewModelScope.launch {
            repository.savedGames.collect { games -> _uiState.update { it.copy(savedGames = games) } }
        }
    }

    fun onSquareTap(position: Position) {
        val ui = _uiState.value
        val game = ui.game
        if (game.isGameOver || ui.isAiThinking || ui.pendingPromotion != null || ui.reviewingGameId != null) return
        if (ui.onlineActive && ui.onlineColor != game.currentTurn) return
        if (ui.playerMode == PlayerMode.VS_AI && game.currentTurn == PieceColor.BLACK) return

        val selected = ui.selected
        val clickedPiece = game.board[position]
        if (selected == null) {
            if (clickedPiece?.color == game.currentTurn) selectSquare(position)
            return
        }
        if (selected == position) {
            _uiState.update { it.copy(selected = null, legalTargets = emptyList()) }
            return
        }

        val options = ui.legalTargets.filter { it.to == position }
        if (options.isNotEmpty()) {
            if (options.size > 1 && options.any { it.promotionType != null }) {
                _uiState.update { it.copy(pendingPromotion = options) }
            } else {
                commitMove(options.first())
            }
            return
        }
        if (clickedPiece?.color == game.currentTurn) selectSquare(position)
        else _uiState.update { it.copy(selected = null, legalTargets = emptyList()) }
    }

    private fun selectSquare(position: Position) {
        val state = _uiState.value.game
        _uiState.update {
            it.copy(selected = position, legalTargets = MoveValidator.legalMovesFrom(state, position))
        }
    }

    fun choosePromotion(type: PieceType) {
        val move = _uiState.value.pendingPromotion?.firstOrNull { it.promotionType == type }
        _uiState.update { it.copy(pendingPromotion = null) }
        if (move != null) commitMove(move)
    }

    private fun commitMove(move: Move) {
        val ui = _uiState.value
        val puzzleId = ui.activePuzzleId
        if (puzzleId != null) {
            val puzzle = PuzzleRepository.puzzles.firstOrNull { it.id == puzzleId }
            val expected = puzzle?.solutionUci?.getOrNull(ui.game.moveHistory.size)
            if (expected != null && expected != move.toUci()) {
                _uiState.update { it.copy(puzzleFeedback = "Chưa đúng, hãy thử nước khác.") }
                return
            }
        }

        val next = MoveValidator.applyMove(ui.game, move) ?: return
        _uiState.update {
            it.copy(
                game = next,
                selected = null,
                legalTargets = emptyList(),
                puzzleFeedback = if (puzzleId != null) "Chính xác! Bạn đã giải được bài." else null
            )
        }
        savedStateHandle[KEY_GAME] = next
        if (ui.onlineActive && ui.onlineRoomCode != null) {
            val uci = next.moveHistory.joinToString(" ") { it.toUci() }
            onlineRepository.publish(ui.onlineRoomCode, ChessFen.toFen(next), uci, next.status.name)
        }
        maybeSaveFinishedGame(next)
        if (_uiState.value.playerMode == PlayerMode.VS_AI && !next.isGameOver && next.currentTurn == PieceColor.BLACK) {
            runAiTurn(next)
        }
    }

    private fun runAiTurn(position: GameState) {
        _uiState.update { it.copy(isAiThinking = true, selected = null, legalTargets = emptyList()) }
        viewModelScope.launch {
            val move = withContext(Dispatchers.Default) { ChessAi.chooseMove(position, depth = 3) }
            _uiState.update { it.copy(isAiThinking = false) }
            if (move != null && _uiState.value.game == position && _uiState.value.playerMode == PlayerMode.VS_AI) commitMove(move)
        }
    }

    fun undo() {
        // Undo cục bộ khi online sẽ làm hai máy lệch trạng thái; không cho phép thao tác này.
        if (_uiState.value.onlineActive) return
        var restored = MoveValidator.undo(_uiState.value.game) ?: return
        if (_uiState.value.playerMode == PlayerMode.VS_AI && restored.currentTurn == PieceColor.BLACK) {
            restored = MoveValidator.undo(restored) ?: restored
        }
        _uiState.update {
            it.copy(game = restored, selected = null, legalTargets = emptyList(), pendingPromotion = null, puzzleFeedback = null)
        }
        savedStateHandle[KEY_GAME] = restored
        lastSavedGameToken = null
    }

    fun newGame(mode: PlayerMode = _uiState.value.playerMode) {
        removeOnlineListener?.invoke()
        removeOnlineListener = null
        val game = GameState.newGame()
        _uiState.update {
            it.copy(
                game = game,
                selected = null,
                legalTargets = emptyList(),
                playerMode = mode,
                isAiThinking = false,
                pendingPromotion = null,
                onlineRoomCode = null,
                onlineActive = false,
                onlineColor = null,
                onlineError = null,
                activePuzzleId = null,
                reviewingGameId = null,
                puzzleFeedback = null
            )
        }
        savedStateHandle[KEY_GAME] = game
        lastSavedGameToken = null
    }

    fun setMode(mode: PlayerMode) {
        _uiState.update { it.copy(playerMode = mode, isAiThinking = false) }
        if (mode == PlayerMode.VS_AI && _uiState.value.game.currentTurn == PieceColor.BLACK && !_uiState.value.game.isGameOver) {
            runAiTurn(_uiState.value.game)
        }
    }

    fun claimDraw() {
        val game = _uiState.value.game
        val reason = MoveValidator.claimableDrawStatus(game) ?: return
        val ended = game.copy(status = reason)
        _uiState.update { it.copy(game = ended, selected = null, legalTargets = emptyList()) }
        savedStateHandle[KEY_GAME] = ended
        val ui = _uiState.value
        if (ui.onlineActive && ui.onlineRoomCode != null) {
            onlineRepository.publish(
                ui.onlineRoomCode,
                ChessFen.toFen(ended),
                ended.moveHistory.joinToString(" ") { it.toUci() },
                ended.status.name
            )
        }
        maybeSaveFinishedGame(ended)
    }

    fun flipBoard() = _uiState.update { it.copy(flipped = !it.flipped) }
    fun setTheme(theme: BoardTheme) = _uiState.update { it.copy(theme = theme) }

    fun loadPuzzle(index: Int) {
        removeOnlineListener?.invoke()
        removeOnlineListener = null
        val puzzle = PuzzleRepository.puzzles.getOrNull(index) ?: return
        val game = ChessFen.fromFen(puzzle.fen) ?: return
        _uiState.update {
            it.copy(
                game = game,
                selected = null,
                legalTargets = emptyList(),
                playerMode = PlayerMode.TWO_PLAYERS,
                activePuzzleId = puzzle.id,
                puzzleFeedback = puzzle.description,
                pendingPromotion = null,
                onlineActive = false,
                onlineRoomCode = null,
                onlineColor = null,
                reviewingGameId = null,
                isAiThinking = false
            )
        }
        savedStateHandle[KEY_GAME] = game
    }

    fun exitPuzzle() {
        _uiState.update { it.copy(activePuzzleId = null, puzzleFeedback = null) }
        newGame(_uiState.value.playerMode)
    }

    fun createOnlineRoom() {
        _uiState.update { it.copy(onlineError = null) }
        onlineRepository.createRoom { result ->
            result.onSuccess { code -> startOnlineObservation(code) }
                .onFailure { error -> _uiState.update { it.copy(onlineError = error.localizedMessage ?: "Không thể tạo phòng") } }
        }
    }

    fun joinOnlineRoom(code: String) {
        _uiState.update { it.copy(onlineError = null) }
        onlineRepository.joinRoom(code) { result ->
            result.onSuccess { room -> startOnlineObservation(room) }
                .onFailure { error -> _uiState.update { it.copy(onlineError = error.localizedMessage ?: "Không thể tham gia phòng") } }
        }
    }

    private fun startOnlineObservation(code: String) {
        removeOnlineListener?.invoke()
        // Online luôn bắt đầu từ trạng thái trong phòng; không giữ FEN của ván/puzzle trước đó.
        val cleanGame = GameState.newGame()
        savedStateHandle[KEY_GAME] = cleanGame
        lastSavedGameToken = null
        _uiState.update {
            it.copy(
                game = cleanGame,
                selected = null,
                legalTargets = emptyList(),
                pendingPromotion = null,
                activePuzzleId = null,
                puzzleFeedback = null,
                reviewingGameId = null,
                onlineRoomCode = code,
                onlineActive = true,
                onlineColor = null,
                onlineError = null,
                playerMode = PlayerMode.TWO_PLAYERS,
                isAiThinking = false
            )
        }
        removeOnlineListener = onlineRepository.observe(
            code,
            onUpdate = { update ->
                val myColor = when {
                    update.myUid.isNotBlank() && update.myUid == update.whiteUid -> PieceColor.WHITE
                    update.myUid.isNotBlank() && update.myUid == update.blackUid -> PieceColor.BLACK
                    else -> null
                }
                _uiState.update { it.copy(onlineColor = myColor) }
                val currentGame = _uiState.value.game
                val localMoves = currentGame.moveHistory.joinToString(" ") { it.toUci() }
                val incomingStatus = runCatching { GameStatus.valueOf(update.status) }.getOrNull()
                if (update.uciMoves != localMoves) {
                    val replayed = ChessFen.replayUci(update.uciMoves)
                    // Chỉ chấp nhận dữ liệu replay hợp lệ; FEN là phương án dự phòng khi server gửi vị trí khác.
                    val base = if (ChessFen.toFen(replayed).substringBeforeLast(' ') == update.fen.substringBeforeLast(' ')) {
                        replayed
                    } else {
                        ChessFen.fromFen(update.fen) ?: replayed
                    }
                    val synced = if (incomingStatus != null) base.copy(status = incomingStatus) else base
                    _uiState.update { it.copy(game = synced, selected = null, legalTargets = emptyList()) }
                    savedStateHandle[KEY_GAME] = synced
                    maybeSaveFinishedGame(synced)
                } else if (incomingStatus != null && incomingStatus != currentGame.status) {
                    val synced = currentGame.copy(status = incomingStatus)
                    _uiState.update { it.copy(game = synced) }
                    savedStateHandle[KEY_GAME] = synced
                    maybeSaveFinishedGame(synced)
                }
            },
            onError = { message -> _uiState.update { it.copy(onlineError = message) } }
        )
    }

    private fun maybeSaveFinishedGame(game: GameState) {
        if (!game.isGameOver) return
        val token = "${ChessFen.toFen(game)}|${game.status}|${game.moveHistory.size}"
        if (lastSavedGameToken == token) return
        lastSavedGameToken = token
        viewModelScope.launch(Dispatchers.IO) { repository.saveFinishedGame(game) }
    }

    fun reviewSavedGame(saved: SavedGameEntity) {
        removeOnlineListener?.invoke()
        removeOnlineListener = null
        val replayed = ChessFen.replayUci(saved.movesUci).let { replay ->
            val savedStatus = runCatching { GameStatus.valueOf(saved.result) }.getOrNull()
            if (savedStatus != null) replay.copy(status = savedStatus) else replay
        }
        _uiState.update {
            it.copy(
                game = replayed,
                selected = null,
                legalTargets = emptyList(),
                playerMode = PlayerMode.TWO_PLAYERS,
                reviewingGameId = saved.id,
                onlineActive = false,
                onlineRoomCode = null,
                onlineColor = null,
                activePuzzleId = null,
                puzzleFeedback = null,
                pendingPromotion = null,
                isAiThinking = false
            )
        }
        savedStateHandle[KEY_GAME] = replayed
    }

    fun deleteSavedGame(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { repository.delete(id) }
    }

    override fun onCleared() {
        removeOnlineListener?.invoke()
        super.onCleared()
    }

    companion object {
        private const val KEY_GAME = "chess_game_state"
    }
}
