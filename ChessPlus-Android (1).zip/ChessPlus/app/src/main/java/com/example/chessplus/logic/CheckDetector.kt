package com.example.chessplus.logic

import com.example.chessplus.model.Board
import com.example.chessplus.model.PieceColor
import com.example.chessplus.model.PieceType
import com.example.chessplus.model.Position

object CheckDetector {
    fun isInCheck(board: Board, color: PieceColor): Boolean {
        val king = board.findKing(color) ?: return true
        return isSquareAttacked(board, king, color.opposite())
    }

    /** Kiểm tra một ô có bị quân màu [byColor] tấn công hay không. */
    fun isSquareAttacked(board: Board, target: Position, byColor: PieceColor): Boolean {
        if (!target.isOnBoard) return false

        // Tốt tấn công chéo, khác với hướng di chuyển thẳng.
        val pawnSourceRow = target.row - if (byColor == PieceColor.WHITE) -1 else 1
        for (dc in intArrayOf(-1, 1)) {
            val source = Position(pawnSourceRow, target.col + dc)
            val piece = board[source]
            if (piece?.color == byColor && piece.type == PieceType.PAWN) return true
        }

        val knightOffsets = listOf(
            -2 to -1, -2 to 1, -1 to -2, -1 to 2,
            1 to -2, 1 to 2, 2 to -1, 2 to 1
        )
        for ((dr, dc) in knightOffsets) {
            val piece = board[Position(target.row + dr, target.col + dc)]
            if (piece?.color == byColor && piece.type == PieceType.KNIGHT) return true
        }

        for (dr in -1..1) for (dc in -1..1) {
            if (dr == 0 && dc == 0) continue
            val piece = board[Position(target.row + dr, target.col + dc)]
            if (piece?.color == byColor && piece.type == PieceType.KING) return true
        }

        val directions = listOf(
            -1 to 0, 1 to 0, 0 to -1, 0 to 1,
            -1 to -1, -1 to 1, 1 to -1, 1 to 1
        )
        for ((dr, dc) in directions) {
            var row = target.row + dr
            var col = target.col + dc
            var distance = 1
            while (row in 0..7 && col in 0..7) {
                val piece = board[Position(row, col)]
                if (piece != null) {
                    if (piece.color == byColor) {
                        val orthogonal = dr == 0 || dc == 0
                        val attacksAlongRay = when (piece.type) {
                            PieceType.QUEEN -> true
                            PieceType.ROOK -> orthogonal
                            PieceType.BISHOP -> !orthogonal
                            PieceType.KING -> distance == 1
                            else -> false
                        }
                        if (attacksAlongRay) return true
                    }
                    break
                }
                row += dr
                col += dc
                distance++
            }
        }
        return false
    }
}
