package com.example.chessplus.logic

import com.example.chessplus.model.*

/** Sinh nước đi theo luật cờ vua; mọi nước đi trả về đều không để vua mình bị chiếu. */
object MoveValidator {
    private val promotionTypes = listOf(
        PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT
    )

    fun legalMoves(state: GameState, color: PieceColor = state.currentTurn): List<Move> {
        if (state.isGameOver) return emptyList()
        return state.board.pieces()
            .asSequence()
            .filter { it.color == color }
            .flatMap { pseudoLegalMovesFrom(state, it.position, includeCastling = true).asSequence() }
            .filter { move ->
                val next = applyMoveRaw(state, move)
                !CheckDetector.isInCheck(next.board, color)
            }
            .toList()
    }

    fun legalMovesFrom(state: GameState, from: Position): List<Move> {
        val piece = state.board[from] ?: return emptyList()
        if (piece.color != state.currentTurn || state.isGameOver) return emptyList()
        return legalMoves(state).filter { it.from == from }
    }

    fun isLegalMove(state: GameState, move: Move): Boolean =
        legalMoves(state).any { it.from == move.from && it.to == move.to && it.promotionType == move.promotionType }

    private fun pseudoLegalMovesFrom(
        state: GameState,
        from: Position,
        includeCastling: Boolean
    ): List<Move> {
        val piece = state.board[from] ?: return emptyList()
        val result = mutableListOf<Move>()
        val board = state.board

        fun addIfAvailable(to: Position) {
            if (!to.isOnBoard) return
            val target = board[to]
            if (target?.color == piece.color || target?.type == PieceType.KING) return
            result += Move(from, to, capturedPiece = target)
        }

        when (piece.type) {
            PieceType.PAWN -> {
                val direction = if (piece.color == PieceColor.WHITE) -1 else 1
                val startRow = if (piece.color == PieceColor.WHITE) 6 else 1
                val promotionRow = if (piece.color == PieceColor.WHITE) 0 else 7
                val one = Position(from.row + direction, from.col)
                if (one.isOnBoard && board[one] == null) {
                    addPawnMove(result, from, one, null, promotionRow)
                    val two = Position(from.row + 2 * direction, from.col)
                    if (from.row == startRow && board[two] == null) {
                        result += Move(from, two)
                    }
                }
                for (dc in intArrayOf(-1, 1)) {
                    val to = Position(from.row + direction, from.col + dc)
                    if (!to.isOnBoard) continue
                    val target = board[to]
                    if (target != null && target.color != piece.color && target.type != PieceType.KING) {
                        addPawnMove(result, from, to, target, promotionRow)
                    } else if (state.enPassantTarget == to) {
                        val capturedPosition = Position(from.row, to.col)
                        val captured = board[capturedPosition]
                        if (captured?.type == PieceType.PAWN && captured.color != piece.color) {
                            result += Move(from, to, capturedPiece = captured, isEnPassant = true)
                        }
                    }
                }
            }

            PieceType.KNIGHT -> {
                val offsets = listOf(
                    -2 to -1, -2 to 1, -1 to -2, -1 to 2,
                    1 to -2, 1 to 2, 2 to -1, 2 to 1
                )
                offsets.forEach { (dr, dc) -> addIfAvailable(Position(from.row + dr, from.col + dc)) }
            }

            PieceType.BISHOP -> addSlidingMoves(board, piece, from, result, diagonal = true, straight = false)
            PieceType.ROOK -> addSlidingMoves(board, piece, from, result, diagonal = false, straight = true)
            PieceType.QUEEN -> addSlidingMoves(board, piece, from, result, diagonal = true, straight = true)
            PieceType.KING -> {
                for (dr in -1..1) for (dc in -1..1) {
                    if (dr != 0 || dc != 0) addIfAvailable(Position(from.row + dr, from.col + dc))
                }
                if (includeCastling) addCastlingMoves(state, piece, result)
            }
        }
        return result
    }

    private fun addPawnMove(
        output: MutableList<Move>,
        from: Position,
        to: Position,
        captured: Piece?,
        promotionRow: Int
    ) {
        if (to.row == promotionRow) {
            promotionTypes.forEach { output += Move(from, to, capturedPiece = captured, promotionType = it) }
        } else {
            output += Move(from, to, capturedPiece = captured)
        }
    }

    private fun addSlidingMoves(
        board: Board,
        piece: Piece,
        from: Position,
        output: MutableList<Move>,
        diagonal: Boolean,
        straight: Boolean
    ) {
        val directions = buildList {
            if (straight) addAll(listOf(-1 to 0, 1 to 0, 0 to -1, 0 to 1))
            if (diagonal) addAll(listOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1))
        }
        for ((dr, dc) in directions) {
            var row = from.row + dr
            var col = from.col + dc
            while (row in 0..7 && col in 0..7) {
                val to = Position(row, col)
                val target = board[to]
                if (target == null) {
                    output += Move(from, to)
                } else {
                    if (target.color != piece.color && target.type != PieceType.KING) {
                        output += Move(from, to, capturedPiece = target)
                    }
                    break
                }
                row += dr
                col += dc
            }
        }
    }

    private fun addCastlingMoves(state: GameState, king: Piece, output: MutableList<Move>) {
        val homeRow = if (king.color == PieceColor.WHITE) 7 else 0
        if (king.position != Position(homeRow, 4)) return
        if (CheckDetector.isInCheck(state.board, king.color)) return

        fun tryCastle(kingSide: Boolean) {
            if (!state.castlingRights.canCastle(king.color, kingSide)) return
            val rookCol = if (kingSide) 7 else 0
            val rook = state.board[Position(homeRow, rookCol)]
            if (rook?.type != PieceType.ROOK || rook.color != king.color) return
            val emptyCols = if (kingSide) listOf(5, 6) else listOf(1, 2, 3)
            if (emptyCols.any { state.board[Position(homeRow, it)] != null }) return
            val transitCols = if (kingSide) listOf(5, 6) else listOf(3, 2)
            if (transitCols.any {
                    CheckDetector.isSquareAttacked(
                        state.board, Position(homeRow, it), king.color.opposite()
                    )
                }) return
            val destination = Position(homeRow, if (kingSide) 6 else 2)
            output += Move(king.position, destination, isCastling = true)
        }
        tryCastle(kingSide = true)
        tryCastle(kingSide = false)
    }

    /** Áp dụng một nước đi hợp lệ, cập nhật SAN, quyền nhập thành, en-passant và luật hòa. */
    fun applyMove(state: GameState, move: Move): GameState? {
        val legal = legalMoves(state).firstOrNull {
            it.from == move.from && it.to == move.to && it.promotionType == move.promotionType
        } ?: return null
        val next = applyMoveRaw(state, legal)
        val repetitionKey = GameState.positionKey(next)
        val repetitions = state.repetitionCounts + (repetitionKey to ((state.repetitionCounts[repetitionKey] ?: 0) + 1))
        val san = sanFor(state, legal, next)
        val withHistory = next.copy(
            moveHistory = state.moveHistory + legal.copy(notation = san),
            undoHistory = state.undoHistory + GameState.snapshot(state),
            repetitionCounts = repetitions
        )
        return withHistory.copy(status = determineStatus(withHistory))
    }

    /** Hàm áp dụng nội bộ cho kiểm tra hợp lệ và tìm kiếm AI; không sinh SAN/trạng thái kết thúc. */
    fun applyMoveRaw(state: GameState, move: Move): GameState {
        val moving = state.board[move.from] ?: return state
        var board = state.board
        board = board.put(null, move.from)
        if (move.isEnPassant) board = board.put(null, Position(move.from.row, move.to.col))
        board = board.put(
            moving.copy(type = move.promotionType ?: moving.type, position = move.to),
            move.to
        )

        if (move.isCastling) {
            val row = move.from.row
            if (move.to.col == 6) {
                val rook = board[Position(row, 7)]
                board = board.put(null, Position(row, 7)).put(rook, Position(row, 5))
            } else {
                val rook = board[Position(row, 0)]
                board = board.put(null, Position(row, 0)).put(rook, Position(row, 3))
            }
        }

        var rights = state.castlingRights
        if (moving.type == PieceType.KING) {
            rights = if (moving.color == PieceColor.WHITE) {
                rights.copy(whiteKingSide = false, whiteQueenSide = false)
            } else {
                rights.copy(blackKingSide = false, blackQueenSide = false)
            }
        }
        if (moving.type == PieceType.ROOK) rights = removeRookRight(rights, moving.color, move.from)
        val capturedPosition = if (move.isEnPassant) Position(move.from.row, move.to.col) else move.to
        val actualCaptured = state.board[capturedPosition]
        if (actualCaptured?.type == PieceType.ROOK) {
            rights = removeRookRight(rights, actualCaptured.color, capturedPosition)
        }

        val direction = if (moving.color == PieceColor.WHITE) -1 else 1
        val ep = if (moving.type == PieceType.PAWN && kotlin.math.abs(move.to.row - move.from.row) == 2) {
            Position(move.from.row + direction, move.from.col)
        } else null
        val isCapture = actualCaptured != null || move.isEnPassant
        val halfMove = if (moving.type == PieceType.PAWN || isCapture) 0 else state.halfMoveClock + 1
        val fullMove = state.fullMoveNumber + if (moving.color == PieceColor.BLACK) 1 else 0
        return state.copy(
            board = board,
            currentTurn = moving.color.opposite(),
            castlingRights = rights,
            enPassantTarget = ep,
            halfMoveClock = halfMove,
            fullMoveNumber = fullMove,
            status = GameStatus.ACTIVE
        )
    }

    fun undo(state: GameState): GameState? {
        val snapshot = state.undoHistory.lastOrNull() ?: return null
        return state.copy(
            board = snapshot.board,
            currentTurn = snapshot.currentTurn,
            castlingRights = snapshot.castlingRights,
            enPassantTarget = snapshot.enPassantTarget,
            halfMoveClock = snapshot.halfMoveClock,
            fullMoveNumber = snapshot.fullMoveNumber,
            moveHistory = state.moveHistory.dropLast(1),
            undoHistory = state.undoHistory.dropLast(1),
            status = GameStatus.ACTIVE,
            repetitionCounts = recomputeRepetitionCounts(state, snapshot)
        ).let { restored -> restored.copy(status = determineStatus(restored)) }
    }

    fun determineStatus(state: GameState): GameStatus {
        val inCheck = CheckDetector.isInCheck(state.board, state.currentTurn)
        val moves = legalMoves(state.copy(status = GameStatus.ACTIVE))
        if (moves.isEmpty()) return if (inCheck) GameStatus.CHECKMATE else GameStatus.STALEMATE
        // Luật 75 nước và lặp 5 lần là hòa tự động theo FIDE.
        if (state.halfMoveClock >= 150) return GameStatus.DRAW_SEVENTY_FIVE_MOVE
        if ((state.repetitionCounts[GameState.positionKey(state)] ?: 0) >= 5) {
            return GameStatus.DRAW_FIVEFOLD_REPETITION
        }
        if (isInsufficientMaterial(state.board)) return GameStatus.DRAW_INSUFFICIENT_MATERIAL
        return if (inCheck) GameStatus.CHECK else GameStatus.ACTIVE
    }

    /** 50 nước và lặp 3 lần là quyền yêu cầu hòa của người chơi, không tự động kết thúc. */
    fun claimableDrawStatus(state: GameState): GameStatus? {
        if (state.isGameOver) return null
        if (state.halfMoveClock >= 100) return GameStatus.DRAW_FIFTY_MOVE
        if ((state.repetitionCounts[GameState.positionKey(state)] ?: 0) >= 3) {
            return GameStatus.DRAW_THREEFOLD
        }
        return null
    }

    fun isInsufficientMaterial(board: Board): Boolean {
        val nonKings = board.pieces().filter { it.type != PieceType.KING }
        if (nonKings.isEmpty()) return true
        if (nonKings.any { it.type == PieceType.PAWN || it.type == PieceType.ROOK || it.type == PieceType.QUEEN }) {
            return false
        }
        if (nonKings.size == 1) return true // K+B vs K hoặc K+N vs K
        if (nonKings.all { it.type == PieceType.BISHOP }) {
            val squareColors = nonKings.map { (it.position.row + it.position.col) % 2 }.toSet()
            return squareColors.size == 1
        }
        return false
    }

    private fun removeRookRight(rights: CastlingRights, color: PieceColor, pos: Position): CastlingRights {
        return when {
            color == PieceColor.WHITE && pos == Position(7, 0) -> rights.copy(whiteQueenSide = false)
            color == PieceColor.WHITE && pos == Position(7, 7) -> rights.copy(whiteKingSide = false)
            color == PieceColor.BLACK && pos == Position(0, 0) -> rights.copy(blackQueenSide = false)
            color == PieceColor.BLACK && pos == Position(0, 7) -> rights.copy(blackKingSide = false)
            else -> rights
        }
    }

    private fun recomputeRepetitionCounts(state: GameState, snapshot: PositionSnapshot): Map<String, Int> {
        val removedKey = GameState.positionKey(state)
        val copied = state.repetitionCounts.toMutableMap()
        val count = copied[removedKey] ?: 0
        if (count <= 1) copied.remove(removedKey) else copied[removedKey] = count - 1
        val restored = state.copy(
            board = snapshot.board,
            currentTurn = snapshot.currentTurn,
            castlingRights = snapshot.castlingRights,
            enPassantTarget = snapshot.enPassantTarget,
            halfMoveClock = snapshot.halfMoveClock,
            fullMoveNumber = snapshot.fullMoveNumber
        )
        val restoredKey = GameState.positionKey(restored)
        copied[restoredKey] = (copied[restoredKey] ?: 0).coerceAtLeast(1)
        return copied
    }

    private fun sanFor(before: GameState, move: Move, after: GameState): String {
        if (move.isCastling) {
            val base = if (move.to.col == 6) "O-O" else "O-O-O"
            val replies = legalMoves(after)
            return when {
                replies.isEmpty() && CheckDetector.isInCheck(after.board, after.currentTurn) -> "$base#"
                CheckDetector.isInCheck(after.board, after.currentTurn) -> "$base+"
                else -> base
            }
        }
        val piece = before.board[move.from] ?: return move.to.toAlgebraic()
        val capture = move.capturedPiece != null || move.isEnPassant
        val sameDestination = legalMoves(before).filter {
            it.from != move.from && it.to == move.to && before.board[it.from]?.type == piece.type
        }
        val disambiguation = if (piece.type == PieceType.PAWN) {
            if (capture) ('a'.code + move.from.col).toChar().toString() else ""
        } else if (sameDestination.isEmpty()) {
            ""
        } else {
            val sameFile = sameDestination.any { it.from.col == move.from.col }
            val sameRank = sameDestination.any { it.from.row == move.from.row }
            when {
                !sameFile -> ('a'.code + move.from.col).toChar().toString()
                !sameRank -> (8 - move.from.row).toString()
                else -> "${('a'.code + move.from.col).toChar()}${8 - move.from.row}"
            }
        }
        val base = buildString {
            append(piece.type.san)
            append(disambiguation)
            if (capture) append('x')
            append(move.to.toAlgebraic())
            move.promotionType?.let { append("=${it.san}") }
        }
        val nextMoves = legalMoves(after)
        return when {
            nextMoves.isEmpty() && CheckDetector.isInCheck(after.board, after.currentTurn) -> "$base#"
            CheckDetector.isInCheck(after.board, after.currentTurn) -> "$base+"
            else -> base
        }
    }
}
