package com.example.chessplus.model

import java.io.Serializable

/** Bàn cờ bất biến: mỗi nước đi tạo một Board mới để StateFlow/Compose nhận biết thay đổi. */
data class Board(val squares: List<List<Piece?>>) : Serializable {
    init {
        require(squares.size == 8 && squares.all { it.size == 8 }) {
            "Bàn cờ phải có kích thước 8x8"
        }
    }

    operator fun get(position: Position): Piece? =
        if (position.isOnBoard) squares[position.row][position.col] else null

    fun pieces(): List<Piece> = squares.flatten().filterNotNull()

    fun findKing(color: PieceColor): Position? =
        pieces().firstOrNull { it.color == color && it.type == PieceType.KING }?.position

    fun put(piece: Piece?, position: Position): Board {
        require(position.isOnBoard)
        val next = squares.map { it.toMutableList() }.toMutableList()
        next[position.row][position.col] = piece?.copy(position = position)
        return Board(next.map { it.toList() })
    }

    fun move(from: Position, to: Position, promotion: PieceType? = null): Board {
        val moving = this[from] ?: return this
        return put(null, from).put(
            moving.copy(type = promotion ?: moving.type, position = to),
            to
        )
    }

    companion object {
        fun empty(): Board = Board(List(8) { List(8) { null } })

        fun initial(): Board {
            val cells = MutableList(8) { MutableList<Piece?>(8) { null } }
            val backRank = listOf(
                PieceType.ROOK, PieceType.KNIGHT, PieceType.BISHOP, PieceType.QUEEN,
                PieceType.KING, PieceType.BISHOP, PieceType.KNIGHT, PieceType.ROOK
            )
            for (col in 0..7) {
                cells[0][col] = Piece(backRank[col], PieceColor.BLACK, Position(0, col))
                cells[1][col] = Piece(PieceType.PAWN, PieceColor.BLACK, Position(1, col))
                cells[6][col] = Piece(PieceType.PAWN, PieceColor.WHITE, Position(6, col))
                cells[7][col] = Piece(backRank[col], PieceColor.WHITE, Position(7, col))
            }
            return Board(cells.map { it.toList() })
        }
    }
}
