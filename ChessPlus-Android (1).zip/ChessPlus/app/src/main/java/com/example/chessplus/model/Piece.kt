package com.example.chessplus.model

import java.io.Serializable

enum class PieceType(val san: String, val material: Int, val symbol: String) : Serializable {
    KING("K", 20_000, "♔"),
    QUEEN("Q", 900, "♕"),
    ROOK("R", 500, "♖"),
    BISHOP("B", 330, "♗"),
    KNIGHT("N", 320, "♘"),
    PAWN("", 100, "♙")
}

enum class PieceColor : Serializable {
    WHITE, BLACK;

    fun opposite(): PieceColor = if (this == WHITE) BLACK else WHITE
}

data class Position(val row: Int, val col: Int) : Serializable {
    val isOnBoard: Boolean get() = row in 0..7 && col in 0..7

    fun toAlgebraic(): String {
        require(isOnBoard) { "Vị trí nằm ngoài bàn cờ: $this" }
        return "${('a'.code + col).toChar()}${8 - row}"
    }

    companion object {
        fun fromAlgebraic(square: String): Position? {
            if (square.length != 2) return null
            val col = square[0].lowercaseChar() - 'a'
            val rank = square[1].digitToIntOrNull() ?: return null
            val position = Position(8 - rank, col)
            return position.takeIf { it.isOnBoard }
        }
    }
}

data class Piece(
    val type: PieceType,
    val color: PieceColor,
    val position: Position
) : Serializable {
    fun unicode(): String = when (color) {
        PieceColor.WHITE -> type.symbol
        PieceColor.BLACK -> when (type) {
            PieceType.KING -> "♚"
            PieceType.QUEEN -> "♛"
            PieceType.ROOK -> "♜"
            PieceType.BISHOP -> "♝"
            PieceType.KNIGHT -> "♞"
            PieceType.PAWN -> "♟"
        }
    }
}
