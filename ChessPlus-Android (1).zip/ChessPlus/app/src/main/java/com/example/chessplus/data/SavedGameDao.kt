package com.example.chessplus.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedGameDao {
    @Insert suspend fun insert(game: SavedGameEntity): Long

    @Query("SELECT * FROM saved_games ORDER BY finishedAt DESC")
    fun observeAll(): Flow<List<SavedGameEntity>>

    @Query("DELETE FROM saved_games WHERE id = :id")
    suspend fun delete(id: Long)
}
