package com.example.chessplus.viewmodel

import com.example.chessplus.data.SavedGameEntity
import com.example.chessplus.model.GameState
import com.example.chessplus.model.Move
import com.example.chessplus.model.PieceColor
import com.example.chessplus.model.Position
import java.io.Serializable

enum class PlayerMode { TWO_PLAYERS, VS_AI }
enum class BoardTheme { CLASSIC, WOOD, MARBLE, DARK }

data class ChessUiState(
    val game: GameState = GameState.newGame(),
    val selected: Position? = null,
    val legalTargets: List<Move> = emptyList(),
    val flipped: Boolean = false,
    val playerMode: PlayerMode = PlayerMode.TWO_PLAYERS,
    val isAiThinking: Boolean = false,
    val pendingPromotion: List<Move>? = null,
    val theme: BoardTheme = BoardTheme.CLASSIC,
    val savedGames: List<SavedGameEntity> = emptyList(),
    val reviewingGameId: Long? = null,
    val onlineRoomCode: String? = null,
    val onlineActive: Boolean = false,
    val onlineColor: PieceColor? = null,
    val onlineError: String? = null,
    val activePuzzleId: Int? = null,
    val puzzleFeedback: String? = null
)
