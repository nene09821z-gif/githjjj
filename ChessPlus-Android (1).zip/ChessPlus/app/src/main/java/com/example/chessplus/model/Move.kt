package com.example.chessplus.model

import java.io.Serializable

data class Move(
    val from: Position,
    val to: Position,
    val capturedPiece: Piece? = null,
    val isCastling: Boolean = false,
    val isEnPassant: Boolean = false,
    val promotionType: PieceType? = null,
    /** Ký hiệu SAN được gắn sau khi xác định trạng thái sau nước đi. */
    val notation: String = ""
) : Serializable {
    fun toUci(): String = buildString {
        append(from.toAlgebraic())
        append(to.toAlgebraic())
        promotionType?.let { append(it.san.lowercase()) }
    }
}
