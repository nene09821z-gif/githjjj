package com.example.chessplus.puzzle

data class ChessPuzzle(
    val id: Int,
    val title: String,
    val description: String,
    val fen: String,
    val solutionUci: List<String>
)

object PuzzleRepository {
    // Các bài một nước chiếu bí; người chơi cần tìm nước đi chính xác.
    val puzzles = listOf(
        ChessPuzzle(
            id = 1,
            title = "Chiếu bí hàng cuối",
            description = "Trắng đi và chiếu bí trong một nước.",
            fen = "7k/6pp/5Q2/8/8/8/6PP/6K1 w - - 0 1",
            solutionUci = listOf("f6f8")
        ),
        ChessPuzzle(
            id = 2,
            title = "Hậu kết thúc ván",
            description = "Tìm nước chiếu bí ngay lập tức.",
            fen = "6k1/5ppp/8/8/8/4Q3/5PPP/6K1 w - - 0 1",
            solutionUci = listOf("e3e8")
        )
    )
}
