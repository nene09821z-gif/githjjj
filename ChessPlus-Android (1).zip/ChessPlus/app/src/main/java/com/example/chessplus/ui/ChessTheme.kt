package com.example.chessplus.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.example.chessplus.viewmodel.BoardTheme

@Composable
fun ChessPlusTheme(theme: BoardTheme, content: @Composable () -> Unit) {
    val scheme = when (theme) {
        BoardTheme.DARK -> darkColorScheme(
            primary = Color(0xFFD6A46A),
            secondary = Color(0xFFB7C4D2),
            background = Color(0xFF111827),
            surface = Color(0xFF1F2937)
        )
        else -> lightColorScheme(
            primary = Color(0xFF805333),
            secondary = Color(0xFF5D6B54),
            background = Color(0xFFF7F2E8),
            surface = Color(0xFFFFFBF5)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
