package com.example.chessplus.logic

import com.example.chessplus.model.GameState
import com.example.chessplus.model.PieceColor

/** Các phép kiểm tra kết thúc ván được tách riêng để dễ tái sử dụng và kiểm thử. */
object CheckmateDetector {
    fun isCheckmate(state: GameState, color: PieceColor = state.currentTurn): Boolean {
        val active = state.copy(currentTurn = color, status = com.example.chessplus.model.GameStatus.ACTIVE)
        return CheckDetector.isInCheck(active.board, color) && MoveValidator.legalMoves(active, color).isEmpty()
    }

    fun isStalemate(state: GameState, color: PieceColor = state.currentTurn): Boolean {
        val active = state.copy(currentTurn = color, status = com.example.chessplus.model.GameStatus.ACTIVE)
        return !CheckDetector.isInCheck(active.board, color) && MoveValidator.legalMoves(active, color).isEmpty()
    }
}
