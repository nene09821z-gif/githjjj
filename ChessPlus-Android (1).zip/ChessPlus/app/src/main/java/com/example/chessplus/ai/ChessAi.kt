package com.example.chessplus.ai

import com.example.chessplus.logic.CheckDetector
import com.example.chessplus.logic.MoveValidator
import com.example.chessplus.model.*

/** AI Minimax + Alpha-Beta. Gọi trong Dispatchers.Default để không khóa giao diện. */
object ChessAi {
    private const val MATE_SCORE = 100_000
    private val promotionOrder = listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT)

    // Bảng điểm vị trí đơn giản theo góc nhìn Trắng; Đen dùng phép lật hàng.
    private val pawnTable = arrayOf(
        intArrayOf(0, 0, 0, 0, 0, 0, 0, 0),
        intArrayOf(50, 50, 50, 50, 50, 50, 50, 50),
        intArrayOf(10, 10, 20, 30, 30, 20, 10, 10),
        intArrayOf(5, 5, 10, 25, 25, 10, 5, 5),
        intArrayOf(0, 0, 0, 20, 20, 0, 0, 0),
        intArrayOf(5, -5, -10, 0, 0, -10, -5, 5),
        intArrayOf(5, 10, 10, -20, -20, 10, 10, 5),
        intArrayOf(0, 0, 0, 0, 0, 0, 0, 0)
    )
    private val knightTable = arrayOf(
        intArrayOf(-50, -40, -30, -30, -30, -30, -40, -50),
        intArrayOf(-40, -20, 0, 5, 5, 0, -20, -40),
        intArrayOf(-30, 5, 10, 15, 15, 10, 5, -30),
        intArrayOf(-30, 0, 15, 20, 20, 15, 0, -30),
        intArrayOf(-30, 5, 15, 20, 20, 15, 5, -30),
        intArrayOf(-30, 0, 10, 15, 15, 10, 0, -30),
        intArrayOf(-40, -20, 0, 0, 0, 0, -20, -40),
        intArrayOf(-50, -40, -30, -30, -30, -30, -40, -50)
    )

    fun chooseMove(state: GameState, depth: Int = 3): Move? {
        val color = state.currentTurn
        val moves = orderedMoves(state)
        if (moves.isEmpty()) return null
        var bestMove: Move? = null
        var bestScore = Int.MIN_VALUE
        var alpha = Int.MIN_VALUE + 1
        val beta = Int.MAX_VALUE
        for (move in moves) {
            val child = MoveValidator.applyMoveRaw(state, move)
            val score = search(child, depth - 1, alpha, beta, maximizing = false, aiColor = color, ply = 1)
            if (score > bestScore) {
                bestScore = score
                bestMove = move
            }
            alpha = maxOf(alpha, bestScore)
        }
        return bestMove
    }

    private fun search(
        state: GameState,
        depth: Int,
        alphaStart: Int,
        betaStart: Int,
        maximizing: Boolean,
        aiColor: PieceColor,
        ply: Int
    ): Int {
        val moves = orderedMoves(state)
        if (moves.isEmpty()) {
            return if (CheckDetector.isInCheck(state.board, state.currentTurn)) {
                if (state.currentTurn == aiColor) -MATE_SCORE + ply else MATE_SCORE - ply
            } else 0
        }
        if (state.halfMoveClock >= 150 || MoveValidator.isInsufficientMaterial(state.board)) return 0
        if (depth <= 0) return evaluate(state.board, aiColor)

        var alpha = alphaStart
        var beta = betaStart
        if (maximizing) {
            var best = Int.MIN_VALUE
            for (move in moves) {
                val score = search(
                    MoveValidator.applyMoveRaw(state, move), depth - 1, alpha, beta,
                    maximizing = false, aiColor = aiColor, ply = ply + 1
                )
                best = maxOf(best, score)
                alpha = maxOf(alpha, best)
                if (beta <= alpha) break
            }
            return best
        } else {
            var best = Int.MAX_VALUE
            for (move in moves) {
                val score = search(
                    MoveValidator.applyMoveRaw(state, move), depth - 1, alpha, beta,
                    maximizing = true, aiColor = aiColor, ply = ply + 1
                )
                best = minOf(best, score)
                beta = minOf(beta, best)
                if (beta <= alpha) break
            }
            return best
        }
    }

    private fun orderedMoves(state: GameState): List<Move> =
        MoveValidator.legalMoves(state).sortedByDescending { move ->
            val victim = move.capturedPiece?.type?.material ?: 0
            val attacker = state.board[move.from]?.type?.material ?: 0
            val promotion = move.promotionType?.material ?: 0
            victim * 10 - attacker + promotion
        }

    private fun evaluate(board: Board, perspective: PieceColor): Int {
        var total = 0
        for (piece in board.pieces()) {
            val sign = if (piece.color == perspective) 1 else -1
            val row = if (piece.color == PieceColor.WHITE) piece.position.row else 7 - piece.position.row
            val col = piece.position.col
            val positional = when (piece.type) {
                PieceType.PAWN -> pawnTable[row][col]
                PieceType.KNIGHT -> knightTable[row][col]
                PieceType.BISHOP -> centerBonus(row, col) * 4
                PieceType.ROOK -> if (row == 1) 15 else 0
                PieceType.QUEEN -> centerBonus(row, col) * 2
                PieceType.KING -> -centerBonus(row, col) * 3
            }
            total += sign * (piece.type.material + positional)
        }
        return total
    }

    private fun centerBonus(row: Int, col: Int): Int =
        6 - (kotlin.math.abs(3 - row) + kotlin.math.abs(3 - col))
}
