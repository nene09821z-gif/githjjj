package com.example.chessplus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import com.example.chessplus.data.ChessDatabase
import com.example.chessplus.data.GameRepository
import com.example.chessplus.ui.BoardScreen
import com.example.chessplus.ui.ChessPlusTheme
import com.example.chessplus.viewmodel.ChessViewModel
import com.example.chessplus.viewmodel.ChessViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = GameRepository(ChessDatabase.getInstance(applicationContext).savedGameDao())
        setContent {
            val factory = remember { ChessViewModelFactory(this@MainActivity, intent?.extras, repository) }
            val viewModel: ChessViewModel = viewModel(factory = factory)
            val ui by viewModel.uiState.collectAsStateWithLifecycle()
            ChessPlusTheme(theme = ui.theme) {
                BoardScreen(viewModel)
            }
        }
    }
}
