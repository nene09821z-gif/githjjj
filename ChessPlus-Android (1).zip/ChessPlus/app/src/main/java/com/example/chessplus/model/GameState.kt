package com.example.chessplus.model

import java.io.Serializable

enum class GameStatus : Serializable {
    ACTIVE,
    CHECK,
    CHECKMATE,
    STALEMATE,
    DRAW_FIFTY_MOVE,
    DRAW_THREEFOLD,
    DRAW_SEVENTY_FIVE_MOVE,
    DRAW_FIVEFOLD_REPETITION,
    DRAW_INSUFFICIENT_MATERIAL
}

data class CastlingRights(
    val whiteKingSide: Boolean = true,
    val whiteQueenSide: Boolean = true,
    val blackKingSide: Boolean = true,
    val blackQueenSide: Boolean = true
) : Serializable {
    fun canCastle(color: PieceColor, kingSide: Boolean): Boolean = when (color) {
        PieceColor.WHITE -> if (kingSide) whiteKingSide else whiteQueenSide
        PieceColor.BLACK -> if (kingSide) blackKingSide else blackQueenSide
    }
}

/** Snapshot tối thiểu đủ khôi phục chính xác vị trí khi Undo. */
data class PositionSnapshot(
    val board: Board,
    val currentTurn: PieceColor,
    val castlingRights: CastlingRights,
    val enPassantTarget: Position?,
    val halfMoveClock: Int,
    val fullMoveNumber: Int
) : Serializable

data class GameState(
    val board: Board = Board.initial(),
    val currentTurn: PieceColor = PieceColor.WHITE,
    val moveHistory: List<Move> = emptyList(),
    val status: GameStatus = GameStatus.ACTIVE,
    val castlingRights: CastlingRights = CastlingRights(),
    val enPassantTarget: Position? = null,
    /** Số nửa-nước không có tốt di chuyển hoặc quân bị bắt. */
    val halfMoveClock: Int = 0,
    val fullMoveNumber: Int = 1,
    /** Các vị trí trước đó, dùng cho Undo. */
    val undoHistory: List<PositionSnapshot> = emptyList(),
    /** Khóa vị trí -> số lần xuất hiện, dùng cho luật lặp ba lần. */
    val repetitionCounts: Map<String, Int> = emptyMap()
) : Serializable {
    val isGameOver: Boolean
        get() = status in setOf(
            GameStatus.CHECKMATE,
            GameStatus.STALEMATE,
            GameStatus.DRAW_FIFTY_MOVE,
            GameStatus.DRAW_THREEFOLD,
            GameStatus.DRAW_SEVENTY_FIVE_MOVE,
            GameStatus.DRAW_FIVEFOLD_REPETITION,
            GameStatus.DRAW_INSUFFICIENT_MATERIAL
        )

    companion object {
        fun newGame(): GameState {
            val initial = GameState()
            val key = positionKey(initial)
            return initial.copy(repetitionCounts = mapOf(key to 1))
        }

        fun snapshot(state: GameState) = PositionSnapshot(
            board = state.board,
            currentTurn = state.currentTurn,
            castlingRights = state.castlingRights,
            enPassantTarget = state.enPassantTarget,
            halfMoveClock = state.halfMoveClock,
            fullMoveNumber = state.fullMoveNumber
        )

        /** Khóa vị trí tương đương cho luật lặp: bàn cờ, bên đi, quyền nhập thành, ô en-passant. */
        fun positionKey(state: GameState): String = buildString {
            for (row in 0..7) for (col in 0..7) {
                val piece = state.board[Position(row, col)]
                val symbol = when (piece?.type) {
                    PieceType.KING -> 'K'
                    PieceType.QUEEN -> 'Q'
                    PieceType.ROOK -> 'R'
                    PieceType.BISHOP -> 'B'
                    PieceType.KNIGHT -> 'N'
                    PieceType.PAWN -> 'P'
                    null -> '.'
                }
                append(if (piece?.color == PieceColor.BLACK) symbol.lowercaseChar() else symbol)
            }
            append('|').append(state.currentTurn.name)
            append('|').append(
                listOf(
                    state.castlingRights.whiteKingSide,
                    state.castlingRights.whiteQueenSide,
                    state.castlingRights.blackKingSide,
                    state.castlingRights.blackQueenSide
                ).joinToString("") { if (it) "1" else "0" }
            )
            append('|').append(state.enPassantTarget?.toAlgebraic() ?: "-")
        }
    }
}
