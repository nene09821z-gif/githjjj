package com.example.chessplus.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_games")
data class SavedGameEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val finishedAt: Long,
    val result: String,
    val movesSan: String,
    val movesUci: String,
    val finalFen: String
)
