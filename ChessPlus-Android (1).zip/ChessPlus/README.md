# ChessPlus — Android Chess (Kotlin + Jetpack Compose)

Project Android mẫu hoàn chỉnh theo MVVM, có engine cờ vua độc lập với giao diện, sẵn sàng đưa lên GitHub để build APK bằng GitHub Actions.

## Tính năng

- Chơi 2 người trên cùng thiết bị và đấu AI (Minimax + Alpha-Beta, độ sâu 3).
- Luật cờ: đi quân, nước đi hợp lệ, không tự để vua bị chiếu, nhập thành, en-passant, phong cấp.
- Nhận biết chiếu, chiếu bí, stalemate, hòa 50 nước, lặp vị trí 3 lần và thiếu quân chiếu bí.
- Highlight quân được chọn, ô đích, nước đi gần nhất và vua đang bị chiếu; lật bàn, hiệu ứng nảy nhẹ khi quân đến ô mới và animation màu ô.
- SAN, ví dụ `e4`, `Nf3`, `O-O`, `Qxf7#`; Undo.
- Lưu ván kết thúc bằng Room và phát lại lịch sử nước đi.
- Puzzle một nước chiếu bí, bốn bộ màu bàn cờ, âm thanh đi/ăn quân.
- Phòng online Firebase Realtime Database (cần cấu hình Firebase như dưới đây).
- `SavedStateHandle` giữ trạng thái ván khi Activity bị tái tạo; `StateFlow` cho state UI.

## Cấu trúc

```text
ChessPlus/
├── .github/workflows/android.yml
├── app/
│   ├── src/main/java/com/example/chessplus/
│   │   ├── ai/       # Minimax, Alpha-Beta, material + piece-square tables
│   │   ├── data/     # Room Entity, DAO, Database, Repository
│   │   ├── logic/    # MoveValidator, CheckDetector, FEN
│   │   ├── model/    # Piece, Board, Move, GameState
│   │   ├── online/   # Firebase Realtime Database
│   │   ├── puzzle/   # Puzzle model + dữ liệu mẫu
│   │   ├── ui/       # Compose board, pieces, status, theme
│   │   ├── viewmodel/# StateFlow + SavedStateHandle
│   │   └── MainActivity.kt
│   └── src/test/java/.../MoveValidatorTest.kt
├── build.gradle.kts
├── settings.gradle.kts
└── gradle/wrapper/gradle-wrapper.properties
```

## Build trên GitHub

1. Tạo repository GitHub mới.
2. Giải nén project này, upload toàn bộ nội dung thư mục `ChessPlus/` lên repository (thư mục `.github/` phải được giữ lại).
3. Vào tab **Actions**. Workflow **Android CI** sẽ chạy khi push/PR vào `main` hoặc `master`.
4. Khi workflow hoàn tất, mở run tương ứng → **Artifacts** → tải `ChessPlus-debug-apk`.
5. File APK nằm trong artifact với đường dẫn `app/build/outputs/apk/debug/app-debug.apk`.

CI dùng JDK 17, Gradle 8.13 và chạy cả `:app:testDebugUnitTest` trước khi assemble APK. Không cần `google-services.json` để build hoặc chơi offline.

### Build cục bộ

Mở thư mục project bằng Android Studio tương thích AGP 8.11.1, chọn JDK 17 và cài Android SDK Platform 36. Workflow GitHub cài Gradle 8.13 trực tiếp và gọi lệnh `gradle`; project này không kèm `gradlew`/`gradle-wrapper.jar`.

Trên máy tính đã cài Gradle 8.13, chạy:

```bash
gradle :app:testDebugUnitTest
gradle :app:assembleDebug
```

Có thể tạo Gradle Wrapper ngay trong project bằng `gradle wrapper --gradle-version 8.13`, sau đó dùng `./gradlew` (Linux/macOS) hoặc `gradlew.bat` (Windows).

## Bật chơi online Firebase

Chế độ offline, AI, Room và Puzzle chạy không cần Firebase. Để bật online:

1. Tạo project tại Firebase Console và thêm Android app có package `com.example.chessplus`.
2. Tải `google-services.json` đặt vào `app/google-services.json`.
3. Trong Firebase Authentication, bật **Anonymous** sign-in.
4. Tạo **Realtime Database**.
5. Với GitHub Actions, mã hóa file bằng Base64 rồi thêm repository secret tên `GOOGLE_SERVICES_JSON_BASE64`:

   ```bash
   base64 -w 0 app/google-services.json
   ```

   Copy chuỗi được in ra vào Settings → Secrets and variables → Actions → New repository secret.

6. Chỉ cho phép người đã xác thực đọc/ghi. Ví dụ rules khởi đầu (cần tinh chỉnh theo chính sách ứng dụng trước khi phát hành):

   ```json
   {
     "rules": {
       "chessplus_rooms": {
         "$room": {
           ".read": "auth != null",
           ".write": "auth != null && ((!data.exists() && newData.child('whiteUid').val() == auth.uid) || data.child('whiteUid').val() == auth.uid || data.child('blackUid').val() == auth.uid || (data.child('blackUid').val() == '' && newData.child('blackUid').val() == auth.uid))"
         }
       }
     }
   }
   ```

**Lưu ý bảo mật:** rules mẫu đủ cho thử nghiệm 2 người, chưa phải cơ chế chống gian lận. Trước khi phát hành công khai, nên chuyển việc xác thực lượt đi, giới hạn quyền cập nhật FEN/nước đi và dọn phòng hết hạn sang Cloud Functions hoặc backend tin cậy.

## Luật và các giả định triển khai

- 50 nước và lặp vị trí 3 lần được hiển thị nút yêu cầu hòa; 75 nước và lặp vị trí 5 lần là hòa tự động. Chiếu bí được ưu tiên nếu xảy ra ở nước cuối của ngưỡng 75 nước.
- AI mặc định chơi Đen và chạy độ sâu 3. Độ sâu 4 có thể tăng đáng kể thời gian tính ở các vị trí nhiều nước đi.
- Puzzle mẫu là bài một nước chiếu bí, được kiểm tra bằng nước UCI mong đợi.
- Ván được lưu Room khi kết thúc. Undo trong ván hiện tại không xóa các ván đã lưu trước đó.
- Firebase dùng Anonymous Auth và đồng bộ FEN + danh sách nước UCI. Cần cấu hình Firebase của chính bạn; không nhúng thông tin cấu hình riêng vào mã nguồn công khai nếu tổ chức yêu cầu giữ kín.

## Test

`MoveValidatorTest` kiểm tra số nước đi ban đầu, tốt, mã, quân bị chặn, ghim quân, nhập thành, đi qua ô bị tấn công, en-passant, phong cấp, undo, lặp vị trí, luật 50/75 nước, chiếu bí, stalemate và SAN.
